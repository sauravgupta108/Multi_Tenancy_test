#!/usr/bin/env python3
import os
import sys
import tempfile
import json
import tarfile


if __name__ == "__main__":
    if len(sys.argv) == 2:
        if not sys.argv[1].endswith(".tar.gz"):
            raise ValueError("Invalid file name provided.")

        print("-------BEGIN-------")
        
        conf = {}

        with open("config.json") as config:
            conf = json.load(config)
        
        temp_dest = tempfile.mkdtemp(prefix="deploy_", dir=conf["temp_root"])
        print("Temporary directory created at: ", temp_dest)
        
        # scp user@ip:/path/to/file dest/path
        os.system("scp %s@%s:%s %s" % (conf["user"], 
                                       conf["source_ip"], 
                                       os.path.join(conf["server_path"], sys.argv[1]),
                                       temp_dest))
        print("scp ran.")

        path_downloded_file = os.path.join(temp_dest, sys.argv[1])
        print("Downloded file: ", path_downloded_file)
        if not os.path.isfile(path_downloded_file):
            raise NameError("Error in getting file from server source.")

        build = tarfile.open(path_downloded_file)
        build.extractall(path=conf["destination"])
        build.close()
        print("-------END-------")

    else:
        print("Please provide File Name.")
